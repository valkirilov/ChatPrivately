'use strict';

angular.module('myApp.services', [
  'myApp.services.chat-socket',
  'myApp.services.user-service',
]);
